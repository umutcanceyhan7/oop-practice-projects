import Entity.*;
import Helper.Simulation;

public class Main {
    public static void main(String[] args) {
        Simulation simulation = new Simulation();
        simulation.run();
    }
}