package Entity.Actuator;

public interface Actuator {
    public Object performAction(Object value);
}
