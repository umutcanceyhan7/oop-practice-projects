package Entity.Sensor;

public interface Sensor {
    Object getSensedValue();
    void setSensedValue(Object sensedValue);
}
